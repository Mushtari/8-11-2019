package com.LTI.HibernateMapping.HibMapping;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="auth")
public class Author{

	private long id;
	private String name;
	private String email;
	
	
	
	public Author() {
	}



	public Author(long id, String name, String email) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
	}


	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="myseq1")
	@SequenceGenerator(name="myseq1",sequenceName="mysequence")
	public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}


	@Column(name="name")
	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}


	@Column(name="email")
	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
	
	
	
}
		