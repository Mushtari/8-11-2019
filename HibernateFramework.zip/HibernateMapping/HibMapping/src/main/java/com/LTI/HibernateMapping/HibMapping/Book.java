package com.LTI.HibernateMapping.HibMapping;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="booky")
public class Book {
	private long id;
	private String title;
	private String description;
	private Date publisheDate;
	
	private Author author;

	public Book(long id, String title, String description, Date publisheDate, Author author) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.publisheDate = publisheDate;
		this.author = author;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	@Id
	@Column(name="bookId")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="forjpa")
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	
	@Column(name="title")
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name="descrp")
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	@Temporal(TemporalType.DATE)
	@Column(name="publishDate")
	public Date getPublisheDate() {
		return publisheDate;
	}

	public void setPublisheDate(Date publisheDate) {
		this.publisheDate = publisheDate;
	}

	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="authid")
	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}
	
	
	
	

}
