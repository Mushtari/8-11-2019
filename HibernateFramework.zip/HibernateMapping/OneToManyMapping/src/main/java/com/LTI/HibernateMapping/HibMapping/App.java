package com.LTI.HibernateMapping.HibMapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */ 
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
        EntityManager em=emf.createEntityManager();
        
        System.out.println("Starting Transaction");
        em.getTransaction().begin();
        
        	Category cat=new Category("Computer");
        	
        	Product pc=new Product(" DELL PC", "Quad-Core PC", 1200, cat);
        	
        	Product laptop=new Product("MacBook","Apple High-end laptop", 2100, cat);
        	
        	Product phone = new Product("iPhone 5", "Apple Best-Selling smartphone", 499, cat);
        
        	Product tablet=new Product("iPad 3", "Apple Best-Selling tablet", 1099, cat);
        	em.getTransaction().commit();
        	
        	em.close();  
            emf.close();  
    }
}
