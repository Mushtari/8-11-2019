package com.LTI.JPAHIbEx.JPAHibExmpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class OrderUpd {
	 public static void update()
	    {
	       EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
	       EntityManager em=emf.createEntityManager();
	       
	       
	       
	       System.out.println("Starting Transaction");
	       em.getTransaction().begin();

//	       Query query = em.createQuery("UPDATE Order e SET e.odet ='OutForDelivery' WHERE e.orderId = :or");
//	       query.setParameter("or", 421);
	       Query query = em.createQuery("UPDATE Order e SET e.odet =:det WHERE e.orderId = :or ");
	       query.setParameter("det", "Shipped");
	       query.setParameter("or", 461);
	       int rowsUpdated = query.executeUpdate();
	       System.out.println("entities Updated: " + rowsUpdated);
	       em.getTransaction().commit();
	       System.out.println("Updating Order to DB");
	       
	       @SuppressWarnings("unchecked")
	       List<Order> listOrder=em.createQuery("SELECT e FROM Order e").getResultList();
	       
	       
	       if(listOrder == null){
	    	   System.out.println("No Order Found");
	       }
	       else
	       {
	    	   for(Order employ : listOrder)
	    	   {
	    		   System.out.println("Order Detail="+employ.getOdet()+", Orderid= "+employ.getOrderId()+",Date= "+employ.getOrderDate());
	    	   }
	       }
	       em.close();
	       emf.close();
	    }
	}
