package com.LTI.JPAHIbEx.JPAHibExmpl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OrderInsert {
	 public static void insert()
	    {
	       EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
	       EntityManager em=emf.createEntityManager();
	       System.out.println("Starting Transaction");
	       em.getTransaction().begin();
	  
	   Order o=new Order();
       o.setOdet("Shipping");
       @SuppressWarnings("deprecation")
       Date d=new Date("05/26/2019");
       o.setOrderDate(d);
       em.persist(o);
       em.getTransaction().commit();
       System.out.println("Generated Order Id= " +o.getOrderId());
       Order ol=em.find(Order.class, o.getOrderId());
       System.out.println("got object " + ol.getOdet()+ " "+ol.getOrderId());
     
     @SuppressWarnings("unchecked")
     List<Order> listOrder=em.createQuery("SELECT e FROM Order e").getResultList();
     
     
     if(listOrder == null){
  	   System.out.println("No Order Found");
     }
     else
     {
  	   for(Order employ : listOrder)
  	   {
  		   System.out.println("Order Detail="+employ.getOdet()+", Orderid= "+employ.getOrderId()+",Date= "+employ.getOrderDate());
  	   }
     }
     em.close();
     emf.close();
  }

	       
	       
//	       Order o=new Order();
//	       o.setOdet("OutForDelivery");
//	       @SuppressWarnings("deprecation")
//	       Date d=new Date("04/07/2019");
//	       o.setOrderDate(d);

}
