package com.LTI.JPAHIbEx.JPAHibExmpl;


public class App 
{
    public static void main( String[] args )
    {
    
      OrderInsert oi=new OrderInsert();
      oi.insert();
//      OrderUpd ou=new OrderUpd();
//      ou.update();
//      OrderDel od=new OrderDel();
//      od.delete();
//      OrderDisp os=new OrderDisp();
//      os.display();
      
    }
}
