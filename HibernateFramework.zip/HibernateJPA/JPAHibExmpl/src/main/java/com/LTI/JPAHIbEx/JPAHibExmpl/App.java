package com.LTI.JPAHIbEx.JPAHibExmpl;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class App 
{
    public static void main( String[] args )
    {
       EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
       EntityManager em=emf.createEntityManager();
       
       System.out.println("Starting Transaction");
       em.getTransaction().begin();
       Employer emp=new Employer();
       emp.setName("BENS");
       emp.setBranch("HIBN");

       System.out.println("Saving Employer to DB");
       
       em.persist(emp);
       em.getTransaction().commit();
       System.out.println("Generated Employer Id= " +emp.getEmployerId());
       
       Employer empl=em.find(Employer.class, emp.getEmployerId());
       
       System.out.println("got object " + empl.getName()+ " "+empl.getEmployerId());
       
       @SuppressWarnings("unchecked")
       List<Employer> listEmployer=em.createQuery("SELECT e FROM Employer e").getResultList();
       
       if(listEmployer == null){
    	   System.out.println("No Employer Found");
       }
       else
       {
    	   for(Employer employ : listEmployer)
    	   {
    		   System.out.println("Employer name="+employ.getName()+", Employer id= "+employ.getEmployerId()+",Employer branch= "+employ.getBranch());
    	   }
       }
       em.close();
       emf.close();
    }
}
