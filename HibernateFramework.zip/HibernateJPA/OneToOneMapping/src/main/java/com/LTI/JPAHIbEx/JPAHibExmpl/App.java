package com.LTI.JPAHIbEx.JPAHibExmpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    public static void main( String[] args ) throws IOException
    {
    
    	 EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistence");  
         EntityManager em = emf.createEntityManager( );  
         em.getTransaction( ).begin( );  
        
         Product p=new Product();  
         //p.setId(1);  
         p.setName("DataCable");  
         p.setPrice(200);
         em.persist(p); 
         
         Order o1=new Order();  
         Date d=new Date("05/23/2019");
         o1.setOrderDate(d);  
         o1.setP(p); 
         em.persist(o1); 
         
         
                 
                     
         em.getTransaction().commit();  
           
         em.close();  
         emf.close();  
  }  
    
    
}  
      
   