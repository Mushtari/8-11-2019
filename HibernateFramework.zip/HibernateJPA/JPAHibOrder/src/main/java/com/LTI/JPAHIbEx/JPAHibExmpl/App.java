package com.LTI.JPAHIbEx.JPAHibExmpl;


import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class App 
{
    public static void main( String[] args )
    {
       EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
       EntityManager em=emf.createEntityManager();
       
       
       
       System.out.println("Starting Transaction");
       em.getTransaction().begin();

//       Query query = em.createQuery("UPDATE Order e SET e.odet ='OutForDelivery' WHERE e.orderId = :or");
//       query.setParameter("or", 421);
       Query query = em.createQuery("UPDATE Order e SET e.odet =:det WHERE e.orderId = :or ");
       query.setParameter("det", "Delivered");
       query.setParameter("or", 421);
       int rowsUpdated = query.executeUpdate();
       System.out.println("entities Updated: " + rowsUpdated);
       em.getTransaction().commit();
   
//       Order o=new Order();
//       o.setOdet("Dispatched");
//       @SuppressWarnings("deprecation")
//       Date d=new Date("12/05/2019");
//       o.setOrderDate(d);

       
       
//       Order o=new Order();
//       o.setOdet("OutForDelivery");
//       @SuppressWarnings("deprecation")
//       Date d=new Date("04/07/2019");
//       o.setOrderDate(d);

       System.out.println("Saving Order to DB");
       
//       em.persist(o);
//       em.getTransaction().commit();
//       System.out.println("Generated Order Id= " +o.getOrderId());
//       Order ol=em.find(Order.class, o.getOrderId());
//       System.out.println("got object " + ol.getOdet()+ " "+ol.getOrderId());
       
       @SuppressWarnings("unchecked")
       List<Order> listOrder=em.createQuery("SELECT e FROM Order e").getResultList();
       
       
       if(listOrder == null){
    	   System.out.println("No Order Found");
       }
       else
       {
    	   for(Order employ : listOrder)
    	   {
    		   System.out.println("Order Detail="+employ.getOdet()+", Orderid= "+employ.getOrderId()+",Date= "+employ.getOrderDate());
    	   }
       }
       em.close();
       emf.close();
    }
}
