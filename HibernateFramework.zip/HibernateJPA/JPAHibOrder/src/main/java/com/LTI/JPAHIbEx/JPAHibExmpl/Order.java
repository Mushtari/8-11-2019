package com.LTI.JPAHIbEx.JPAHibExmpl;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="ordertable")
public class Order {
	
	private int orderId;
	private String odet;
	private Date orderDate;
	
	@Id
	@Column(name="orderId")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="mysequence",allocationSize=1)
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
	
	@Column(name="odet")
	public String getOdet() {
		return odet;
	}
	public void setOdet(String odet) {
		this.odet = odet;
	}
	
	@Column(name="orderDate")
	@Temporal(TemporalType.DATE)
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	
	
	
	
	
	
}
