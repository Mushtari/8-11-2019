package com.LTI.HibExamples.StudHibCU;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.LTI.HibExamples.StudHibCU.Students;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 Configuration c=new Configuration().configure();
         StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder().applySettings(c.getProperties());
         SessionFactory sf=c.buildSessionFactory(builder.build());
         Session session=sf.openSession();
         Students stud=new Students();
         stud.setStudName("Mushtari Khan");
         stud.setBranch("JAVA");
         session.beginTransaction();
         session.save(stud);
         session.getTransaction().commit();
    }
}
