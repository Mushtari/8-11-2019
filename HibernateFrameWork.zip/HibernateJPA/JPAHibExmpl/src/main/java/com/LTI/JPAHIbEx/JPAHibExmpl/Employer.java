package com.LTI.JPAHIbEx.JPAHibExmpl;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="employer")
public class Employer {
	
	private int employerId;
	private String name;
	private String branch;
	
	@Id
	@Column(name="employerId")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="mysequence")
	
	public int getEmployerId() {
		return employerId;
	}
	public void setEmployerId(int employerId) {
		this.employerId = employerId;
	}
	
	
	
	
	@Column(name= "name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	@Column(name= "branch")
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	
	public Employer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employer [employerId=" + employerId + ", name=" + name + ", branch=" + branch + "]";
	}
	
	
		
}
