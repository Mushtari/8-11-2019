package com.LTI.JPAHIbEx.JPAHibExmpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class App 
{
    public static void main( String[] args ) throws IOException
    {
    
    	 EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistence");  
         EntityManager em = emf.createEntityManager( );  
         em.getTransaction( ).begin( );  
        
         
         String hql = "select p.price from Product p order by p.price desc";
         // String hql = "select o.orderDate from Order o where o.proId in (select p.proId from Product p)";
         
         Query query = em.createQuery(hql);
         List results =query.getResultList();
         System.out.println(results);
         
//       List<Product> listOrder=em.createQuery("select p.price from Product p order by p.price desc").getResultList();
//       if(listOrder == null){
//    	   System.out.println("No Order Found");
//       }
//       else
//       {
//    	   System.out.println(listOrder);
//    	  
//       }
         
         
         
//         BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//         
//         Product p=new Product();  
//         p.setName(br.readLine());  
//         p.setPrice(br.read());
//         em.persist(p); 
//         
//         Order o1=new Order();  
//        // Date d=new Date("05/23/2019");
//         o1.setOrderDate(new Date(br.readLine()));  
//         o1.setP(p); 
//         em.persist(o1); 
         
                       
                     
         em.getTransaction().commit();  
           
         em.close();  
         emf.close();  
  }  
    
    
}  
      
   