package com.LTI.JPAHIbEx.JPAHibExmpl;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    public static void main( String[] args )
    {
    
    	 EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistence");  
         EntityManager em = emf.createEntityManager( );  
         em.getTransaction( ).begin( );  
        
         Product p=new Product();  
         p.setId(1);  
         p.setName("HeadPhone");  
         p.setPrice(1000);
           
         Product  p2=new Product();  
         p2.setId(2);  
         p2.setName("Speaker");  
         p2.setPrice(2000);
           
         em.persist(p);  
         em.persist(p2);  
           
         Order o1=new Order();  
         Date d=new Date("05/26/2019");
         o1.setOrderDate(d);  
         o1.setP(p);  
           
         Order o2=new Order();  
         Date d1=new Date("03/21/2019");
         o1.setOrderDate(d1);  
         o1.setP(p2);
           
         em.persist(o1);  
         em.persist(o2);  
           
         em.getTransaction().commit();  
           
         em.close();  
         emf.close();  
  }  
    
    
}  
      
   