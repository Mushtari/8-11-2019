package com.LTI.JPAHIbEx.JPAHibExmpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OrderDel {
	public void delete() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
	    EntityManager em=emf.createEntityManager();
	    System.out.println("Starting Transaction");
	    em.getTransaction().begin();

        Order o= em.find(Order.class, 441);
        em.remove(o);
        em.getTransaction().commit();
  
        @SuppressWarnings("unchecked")
	       List<Order> listOrder=em.createQuery("SELECT e FROM Order e").getResultList();
	       
	       
	       if(listOrder == null){
	    	   System.out.println("No Order Found");
	       }
	       else
	       {
	    	   for(Order employ : listOrder)
	    	   {
	    		   System.out.println("Order Detail="+employ.getOdet()+", Orderid= "+employ.getOrderId()+",Date= "+employ.getOrderDate());
	    	   }
	       }
	       em.close();
	       emf.close();
    }

}
