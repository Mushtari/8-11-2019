package com.LTI.HibernateMapping.HibMapping;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Movies")

public class Movies {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq1")
	@SequenceGenerator(name="myseq1",sequenceName="forjpa",allocationSize=1)
	@Column(name="id")
	private long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="releaseDate")
	private Date releaseDate;
	
	@OneToOne(mappedBy="mv",cascade=CascadeType.ALL)
	private Producer address;

	public Movies() {
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public Producer getAddress() {
		return address;
	}

	public void setAddress(Producer address) {
		this.address = address;
	}

	public Movies(long id, String name, Date releaseDate, Producer address) {
		super();
		this.id = id;
		this.name = name;
		this.releaseDate = releaseDate;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Movies [id=" + id + ", name=" + name + ", releaseDate=" + releaseDate + ", address=" + address + "]";
	}

	public Movies(String name, Date releaseDate, Producer address) {
		super();
		this.name = name;
		this.releaseDate = releaseDate;
		this.address = address;
	}

	
	
	
}
