package com.LTI.HibernateMapping.HibMapping;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;


@Entity
@Table(name="Producer")
public class Producer{
	@Id
	@Column(name="pid")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="mysequence",allocationSize=1)
	private int id;
	private String name;
	private String productionName;
	
	public Producer() {
		
	}
	
	@OneToOne 
	@PrimaryKeyJoinColumn
	private Movies mv;
	
	public Producer(int id, String name, String productionName, Movies mv) {
		super();
		this.id = id;
		this.name = name;
		this.productionName = productionName;
		this.mv = mv;
	}
	
	

	public Producer(String name) {
		super();
		this.name = name;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProductionName() {
		return productionName;
	}

	public void setProductionName(String productionName) {
		this.productionName = productionName;
	}

	public Movies getMv() {
		return mv;
	}

	public void setMv(Movies mv) {
		this.mv = mv;
	}

	@Override
	public String toString() {
		return "Producer [id=" + id + ", name=" + name + ", productionName=" + productionName + ", mv=" + mv + "]";
	}



	public void setProducer(Set<Movies> movie) {
		// TODO Auto-generated method stub
		
	}

}

	