//package com.LTI.HibernateMapping.HibMapping;
//
//import java.text.SimpleDateFormat;
//import java.util.HashSet;
//import java.util.Set;
//
//import javax.persistence.EntityManager;
//import javax.persistence.EntityManagerFactory;
//import javax.persistence.OneToOne;
//import javax.persistence.Persistence;
//import javax.persistence.PrimaryKeyJoinColumn;
//
//public class App 
//{
//    public static void main( String[] args ) throws Exception
//    {
//    	EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
//        EntityManager em=emf.createEntityManager();
//        
//        System.out.println("Starting Transaction");
//        em.getTransaction().begin();
//        
//        SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
//       
////        Producer producer=new Producer(12,"Rajamouli","RRPictures");
////    	
////    	Movies movie1=new Movies(12,"BHAHUBALI",sdf.parse("2015-07-27"),12);
//    	Movies movie2=new Movies(24,"BHAHUBALI2",sdf.parse("2017-10-5"),producer);
//    	Movies movie3=new Movies(36,"BHAHUBALI3",sdf.parse("2020-07-26"),producer);
//
//    	Set<Movies> movie=new HashSet<Movies>();
//    	movie.add(movie1);
//    	movie.add(movie2);
//    	movie.add(movie3);
//    
//    	producer.setProducer(movie);
//    	     
//        	em.getTransaction().commit();
//        	
//        	em.close();  
//            emf.close();  
//    }
//}
//
//
//
//
//
//
