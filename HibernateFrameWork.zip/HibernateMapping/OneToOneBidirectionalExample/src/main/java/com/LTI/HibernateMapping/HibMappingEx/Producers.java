package com.LTI.HibernateMapping.HibMappingEx;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="producer")
public class Producers {
	  private int pid;
	  private String name;
	  private String production_name;
	 
	  private Movies movie;
	  
	@Id
	@Column(name="pid")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="gen")                                                   
	//@SequenceGenerator(name="gen", sequenceName="SEQ123",allocationSize=1)         
	@GenericGenerator(name="gen", strategy="foreign", parameters=@Parameter(name="property",value="student")) 

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	@Column(name="name")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name="production_name")
	public String getProduction_name() {
		return production_name;
	}

	public void setProduction_name(String production_name) {
		this.production_name = production_name;
	}

	@OneToOne
	@PrimaryKeyJoinColumn
	public Movies getMovie() {
		return movie;
	}

	public void setMovie(Movies movie) {
		this.movie = movie;
	}

	public Producers(int pid, String name, String production_name, Movies movie) {
		super();
		this.pid = pid;
		this.name = name;
		this.production_name = production_name;
		this.movie = movie;
	}

	public Producers() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Producers [pid=" + pid + ", name=" + name + ", production_name=" + production_name + ", movie=" + movie
				+ "]";
	}

}
