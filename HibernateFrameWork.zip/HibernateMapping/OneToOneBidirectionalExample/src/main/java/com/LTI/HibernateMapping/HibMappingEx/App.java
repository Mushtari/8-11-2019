package com.LTI.HibernateMapping.HibMappingEx;

import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
        EntityManager em=emf.createEntityManager();
       
        System.out.println("Starting Transaction");
        em.getTransaction().begin();
        
        Movies mov =new Movies();
        mov.setId(12);
        mov.setName("BHABHUBALI");
        mov.setRelease_date("12/9/1997");
        mov.setPid(123);
  
      System.out.println("Saving PRODUCER Details to Database");
        
        Producers producer=new Producers();
        producer.setPid(123);
        producer.setName("RAJAMOULI");
        producer.setProduction_name("RM");
      
     
        em.persist(mov);
        em.persist(producer);
        
        em.getTransaction().commit();
        em.close();  
        emf.close();  
     
    }
}

