package com.LTI.HibernateMapping.HibMappingEx;


import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="movies")


public class Movies {
	  private int id;
	  private String name;
	  private String release_date;
	  
	  private int pid;
	  
	  @Id
	  	@Column(name="ID")  
	  	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="gen")                                                   
	  	@SequenceGenerator(name="gen", sequenceName="SEQ123",allocationSize=1)  
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRelease_date() {
		return release_date;
	}
	public void setRelease_date(String release_date) {
		this.release_date = release_date;
	}
	
	@OneToOne(mappedBy="Producers", cascade=CascadeType.ALL)
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	
	
	public Movies(int id, String name, String release_date) {
		super();
		this.id = id;
		this.name = name;
		this.release_date = release_date;
	}
	
	
	public Movies() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public String toString() {
		return "Movies [id=" + id + ", name=" + name + ", release_date=" + release_date + "]";
	}
	

}
