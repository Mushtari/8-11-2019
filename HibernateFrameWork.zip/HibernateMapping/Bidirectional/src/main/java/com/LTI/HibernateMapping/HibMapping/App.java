package com.LTI.HibernateMapping.HibMapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */ 
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
        EntityManager em=emf.createEntityManager();
        
        System.out.println("Starting Transaction");
        em.getTransaction().begin();
        
        	Emplooyee emp=new Emplooyee();
        	
        	Emplooyee_Address ema=new Emplooyee_Address();
        	
        	
        	emp.setEmpId(12);
        	emp.setEmpName("MUSH");
        	emp.setEmplooyeeAddress(ema);
        	em.persist(emp);
        	
        	ema.setAddrId(234);
        	ema.setStreet("RAM NAGAR");
        	ema.setCity("HYD");
        	ema.setState("TELANGANA");
        	ema.setCountry("INDIA");
        	ema.setEmplooyee(emp);
       	  	em.persist(ema);
        
        	em.getTransaction().commit();
        	
        	em.close();  
            emf.close();  
    }
}
