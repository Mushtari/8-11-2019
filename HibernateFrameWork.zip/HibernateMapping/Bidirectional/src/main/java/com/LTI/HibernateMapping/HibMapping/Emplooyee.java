package com.LTI.HibernateMapping.HibMapping;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;


@Entity
@Table(name="address")
public class Emplooyee{
	@Id
	@GeneratedValue
	
	@Column(name="id")
	private int empId;
	
	@Column(name="name")
	private String empName;
	
	@OneToOne(mappedBy="emplooyee")
	private Emplooyee_Address emplooyeeAddress;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Emplooyee_Address getEmplooyeeAddress() {
		return emplooyeeAddress;
	}

	public void setEmplooyeeAddress(Emplooyee_Address emplooyeeAddress) {
		this.emplooyeeAddress = emplooyeeAddress;
	}

	public Emplooyee(int empId, String empName, Emplooyee_Address emplooyeeAddress) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.emplooyeeAddress = emplooyeeAddress;
	}

	public Emplooyee() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Emplooyee [empId=" + empId + ", empName=" + empName + ", emplooyeeAddress=" + emplooyeeAddress + "]";
	}
	
	
	

	
	
}
		