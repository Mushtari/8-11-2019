package com.LTI.HibernateMapping.HibMapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */ 
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
        EntityManager em=emf.createEntityManager();
        
        System.out.println("Starting Transaction");
        em.getTransaction().begin();
        
        	Address ad=new Address();
        	
        	Student st=new Student();
        	ad.setStreet("T NAGAR");
        	ad.setCity("CHENNAI");
        	ad.setCountry("INDIA");
        	ad.setStudent(st);
        	em.persist(ad);
        	
        	st.setFname("PAVI");
        	st.setLname("PARA");
        	st.setAddress(ad);
        	em.persist(st);
        
        	em.getTransaction().commit();
        	
        	em.close();  
            emf.close();  
    }
}
