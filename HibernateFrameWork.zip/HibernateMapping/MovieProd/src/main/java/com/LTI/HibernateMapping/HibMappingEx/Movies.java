package com.LTI.HibernateMapping.HibMappingEx;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="movies")


public class Movies {
	 	@Id
	  	@Column(name="mid")  
	  	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseq")    
	 	@SequenceGenerator(name="myseq", sequenceName="forjpa",allocationSize=1)  
	  private int mid;
	 	
	 @Column(name="mname")
	  private String mname;
	  public Movies() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public Movies(int mid, String mname) {
		super();
		this.mid = mid;
		this.mname = mname;
	}
	@Override
	public String toString() {
		return "Movies [mid=" + mid + ", mname=" + mname + "]";
	}
	public Movies(String mname) {
		super();
		this.mname = mname;
	}
	
	
}
	


	