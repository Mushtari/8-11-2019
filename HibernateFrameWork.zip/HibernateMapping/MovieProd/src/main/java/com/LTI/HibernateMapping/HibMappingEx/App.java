package com.LTI.HibernateMapping.HibMappingEx;


import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
        EntityManager em=emf.createEntityManager();
       
        System.out.println("Starting Transaction");
        em.getTransaction().begin();
        
        Producers producer=new Producers("RAJA");
        
        Movies mov =new Movies("KHO");
        Movies mov1 =new Movies("OK KANMANI");
        List<Movies> s=new ArrayList<>();
        s.add(mov);
		s.add(mov1);
        
        em.persist(s);
        em.persist(mov);
        em.persist(mov1);
        
        em.getTransaction().commit();
        em.close();  
        emf.close();  
        
        System.out.println("Saving PRODUCER Details to Database");
    }
}

