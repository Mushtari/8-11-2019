package com.LTI.HibernateMapping.HibMappingEx;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="producer")
public class Producers {

		  
	@Id
	@Column(name="pid")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseq1")                                                   
	@SequenceGenerator(name="myseq1", sequenceName="forjpa",allocationSize=1)         
	private int pid;
	
	@Column(name="name")
    private String name;
	
	@OneToMany(cascade=CascadeType.ALL)
	private List<Movies> movie=new ArrayList();
	
	public Producers() {}
	
	public Producers(int pid, String name) {
		super();
		this.pid = pid;
		this.name = name;
		
	
	}


	public int getPid() {
		return pid;
	}


	public void setPid(int pid) {
		this.pid = pid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	

	
	
	public List<Movies> getMovie() {
		return movie;
	}

	public Producers(String name, List<Movies> movie) {
		super();
		this.name = name;
		this.movie = movie;
	}

	public void setMovie(List<Movies> movie) {
		this.movie = movie;
	}

	public Producers(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return "Producers [pid=" + pid + ", name=" + name + "]";
	}



}
