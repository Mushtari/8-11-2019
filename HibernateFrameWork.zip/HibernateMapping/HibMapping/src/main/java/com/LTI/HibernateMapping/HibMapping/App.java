package com.LTI.HibernateMapping.HibMapping;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */ 
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory emf=Persistence.createEntityManagerFactory("persistence");
        EntityManager em=emf.createEntityManager();
        
        System.out.println("Starting Transaction");
        em.getTransaction().begin();
        
        Author au=new Author();
        au.setName("Ben");
        au.setEmail("ben@gmail.com");
        em.persist(au);
//        em.getTransaction().commit();
        
        
        Book b=new Book();
        b.setTitle("Wings");
        b.setDescription("Shenverdthebokbtstilikesit");
       // Date d=new Date("12/05/2019");
        b.setPublisheDate(new Date(12/05/2019));
        //em.persist(au);
        b.setAuthor(au);
        
        System.out.println("Saving Book to DB");
        em.persist(b);
        
        em.getTransaction().commit();
       

        
        
    }
}
