package com.LTI.StudEx.StudCU;

public class Students {
	
		    private int id;
		    private String studName;
		    private int rollNo;
		    private String branch;
			public int getId() {
				return id;
			}
			public void setId(int id) {
				this.id = id;
			}
			public String getStudName() {
				return studName;
			}
			public void setStudName(String studName) {
				this.studName = studName;
			}
			public int getRollNo() {
				return rollNo;
			}
			public void setRollNo(int rollNo) {
				this.rollNo = rollNo;
			}
			public String getBranch() {
				return branch;
			}
			public void setBranch(String branch) {
				this.branch = branch;
			}
		    
		   
}
